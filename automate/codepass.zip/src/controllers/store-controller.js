exports.get = (req, res, next) => {
    let id = req.params.id;
    let object = {};
    if(id in database)
        object = database[id];
    res.status(200).send(object);
};

exports.put = (req, res, next) => {
    let id = req.params.id;
    database[id] = req.body;
    res.status(201).send({
        messsage:"Objeto adicionado com sucesso!"
    });
};

exports.delete = (req, res, next) => {
    delete database[req.params.id];
    res.status(200).send({
        messsage:"Objeto removido com sucesso!"
    });
};

// Os objetos serao guardados em uma variavel no 
// proprio server para simular o banco de dados
let database = {};