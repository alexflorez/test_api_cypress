const express = require('express');

const app = express();
const router = express.Router();

app.use(express.json());
app.use(express.urlencoded({extended: false}));

//Carrega rotas
const indexRoute = require('./routes/index-route');
const productRoute = require('./routes/store-route');

app.use('/', indexRoute);
app.use('/store', productRoute);

// To serve the test.html file
app.use(express.static('public'));

module.exports = app;